// /*
// |--------------------------------------------------------------------------
// | MF Sync Scheduler
// |--------------------------------------------------------------------------
// |
// | This file owns the ONE decision point for "should we talk to MFapi right
// | now?". Both development server startup and the production cron job call
// | the exact same runDailySyncIfNeeded() function below - there is no
// | separate dev-only or prod-only sync logic.
// |
// | Two independent layers of protection are combined, as required:
// |
// |   1. mf_sync_status (MySQL table)
// |      Persistent record of whether TODAY's sync already succeeded.
// |      Survives process restarts, crashes, and multi-day downtime.
// |      This answers: "has today's sync already happened?"
// |
// |   2. MySQL advisory lock (GET_LOCK / RELEASE_LOCK)
// |      Prevents two Node processes (or two overlapping triggers on the
// |      same process) from running MFapi sync at the exact same time.
// |      This answers: "is a sync running right now, elsewhere?"
// |
// | An in-memory flag such as `let alreadySynced = false` is intentionally
// | NOT used anywhere here - it would not survive a restart and would not
// | protect against multiple Node instances.
// |
// */

// const cron = require('node-cron');
// const pool = require('./db');
// const { syncLatestNAV, syncAllReturns } = require('./mfSyncService');
// const {
//   hasTodaysSyncSucceeded,
//   markRunning,
//   markSuccess,
//   markFailed,
// } = require('./mfSyncStatusService');

// const SYNC_NAME = 'mf_daily_sync';
// const LOCK_NAME = 'mf_daily_sync_lock';
// // How long (seconds) a process waits for the advisory lock before giving up.
// // Default 0 = do not wait, skip immediately if another process already holds it.
// const LOCK_TIMEOUT_SECONDS = Math.max(0, Number(process.env.MF_SYNC_LOCK_TIMEOUT || 0));

// let schedulerTask = null;

// async function acquireLock(connection, name, timeoutSeconds) {
//   const [rows] = await connection.query('SELECT GET_LOCK(?, ?) AS acquired', [name, timeoutSeconds]);
//   return Number(rows[0]?.acquired) === 1;
// }

// async function releaseLock(connection, name) {
//   try {
//     await connection.query('SELECT RELEASE_LOCK(?)', [name]);
//   } catch (_) {
//     // Releasing a lock we may not hold (e.g. connection already dropped) is not fatal.
//   }
// }

// /**
//  * The single synchronization entry point. Safe to call:
//  *  - every time the dev server starts (`node server.js`)
//  *  - from the production cron schedule
//  *  - concurrently from multiple processes
//  *  - repeatedly within the same process
//  *
//  * @param {string} reason - human-readable trigger, only used for logging.
//  */
// async function runDailySyncIfNeeded(reason = 'sync') {
//   let connection;
//   let locked = false;

//   try {
//     connection = await pool.getConnection();

//     console.log(`[MF SYNC] (${reason}) Checking today's sync status`);

//     locked = await acquireLock(connection, LOCK_NAME, LOCK_TIMEOUT_SECONDS);
//     if (!locked) {
//       console.log('[MF SYNC] Another synchronization is already running.');
//       console.log('[MF SYNC] Skipping duplicate sync.');
//       return { success: true, skipped: true, reason: 'locked' };
//     }
//     console.log('[MF SYNC] Acquired sync lock');

//     const alreadyDone = await hasTodaysSyncSucceeded(SYNC_NAME, connection);
//     if (alreadyDone) {
//       const today = new Date().toISOString().slice(0, 10);
//       console.log("[MF SYNC] Today's sync already completed.");
//       console.log(`[MF SYNC] Date: ${today}`);
//       console.log('[MF SYNC] Skipping MFapi fetch.');
//       return { success: true, skipped: true, reason: 'already-done-today' };
//     }

//     console.log("[MF SYNC] Today's sync not found.");
//     console.log('[MF SYNC] Starting daily MFapi synchronization...');
//     await markRunning(SYNC_NAME, connection);

//     console.log('[MF SYNC] Fetching MFapi latest data');
//     const navResult = await syncLatestNAV();
//     console.log('[MF SYNC] Updating database. NAV result:', navResult);

//     console.log('[MF SYNC] Returns calculation started');
//     const returnsResult = await syncAllReturns();
//     console.log('[MF SYNC] Returns result:', returnsResult);

//     const processed = Number(navResult.fetched || 0);
//     const updated = Number(navResult.updated || 0) + Number(returnsResult.updated || 0);
//     const failed = Number(navResult.invalid || 0) + Number(navResult.failed || 0) + Number(returnsResult.failed || 0);

//     await markSuccess(SYNC_NAME, { processed, updated, failed }, connection);

//     console.log(`[MF SYNC] Total records: ${processed}`);
//     console.log(`[MF SYNC] Updated: ${updated}`);
//     console.log(`[MF SYNC] Failed: ${failed}`);
//     console.log('[MF SYNC] Synchronization successful');

//     return { success: true, skipped: false, nav: navResult, returns: returnsResult };
//   } catch (error) {
//     console.error('[MF SYNC] Synchronization failed:', error.message);
//     console.log("[MF SYNC] Keeping previous successful sync date");
//     try {
//       if (connection) await markFailed(SYNC_NAME, error.message, {}, connection);
//     } catch (statusError) {
//       console.error('[MF SYNC] Could not record failure status:', statusError.message);
//     }
//     return { success: false, skipped: false, error: error.message };
//   } finally {
//     if (connection && locked) {
//       await releaseLock(connection, LOCK_NAME);
//       console.log('[MF SYNC] Releasing sync lock');
//     }
//     if (connection) connection.release();
//   }
// }

// /**
//  * Called once at server startup (dev and prod alike). Runs in the
//  * background so it never blocks the HTTP server from accepting requests.
//  * On a day where the sync already succeeded, this resolves almost
//  * instantly after the DB check (no MFapi call at all).
//  */
// function runStartupSync() {
//   setImmediate(() => {
//     runDailySyncIfNeeded('startup').catch((err) => {
//       console.error('[MF SYNC] Unexpected startup sync error:', err.message);
//     });
//   });
// }

// /**
//  * Registers the recurring production schedule. Uses the SAME
//  * runDailySyncIfNeeded() function as startup, so even if the scheduler
//  * fires twice, or fires right after a manual/startup sync already
//  * succeeded today, the DB status check makes the second call a no-op.
//  */
// function startMFScheduler() {
//   const cronExpression = process.env.MF_SYNC_CRON || '0 23 * * 1-5';
//   const timezone = process.env.MF_SYNC_TIMEZONE || 'Asia/Kolkata';

//   schedulerTask = cron.schedule(
//     cronExpression,
//     () => {
//       runDailySyncIfNeeded('scheduled').catch((err) => {
//         console.error('[MF SYNC] Unexpected scheduled sync error:', err.message);
//       });
//     },
//     { timezone }
//   );

//   console.log(`[MF SYNC] Scheduler active: ${cronExpression} ${timezone}`);
//   return schedulerTask;
// }

// function stopMFScheduler() {
//   if (schedulerTask) {
//     schedulerTask.stop();
//     schedulerTask = null;
//     console.log('[MF SYNC] Scheduler stopped');
//   }
// }

// module.exports = {
//   runStartupSync,
//   startMFScheduler,
//   stopMFScheduler,
//   runDailySyncIfNeeded,
// };





const cron = require("node-cron");

const pool = require("./db");

const {
  syncLatestNAV,
  syncAllReturns,
} = require("./mfSyncService");

const {
  calculateAllRatings,
} = require("./mfRatingRiskService");

const {
  markRunning,
  markSuccess,
  markFailed,
} = require("./mfSyncStatusService");

/*
|--------------------------------------------------------------------------
| CONFIGURATION
|--------------------------------------------------------------------------
*/

const NAV_SYNC_NAME = "mf_nav_sync";
const FULL_SYNC_NAME = "mf_daily_sync";

const STARTUP_LOCK_NAME =
  "mf_startup_sync_lock";

const FULL_SYNC_LOCK_NAME =
  "mf_daily_sync_lock";

const STARTUP_NAV_SYNC =
  String(
    process.env.MF_STARTUP_NAV_SYNC ?? "true"
  ).toLowerCase() === "true";

const STARTUP_FULL_SYNC =
  String(
    process.env.MF_STARTUP_FULL_SYNC ?? "true"
  ).toLowerCase() === "true";

const LOCK_TIMEOUT_SECONDS = Math.max(
  0,
  Number(
    process.env.MF_SYNC_LOCK_TIMEOUT || 0
  )
);

const CRON_EXPRESSION =
  process.env.MF_SYNC_CRON ||
  "15 23 * * 1-5";

const CRON_TIMEZONE =
  process.env.MF_SYNC_TIMEZONE ||
  "Asia/Kolkata";

let schedulerTask = null;

/*
|--------------------------------------------------------------------------
| MYSQL ADVISORY LOCK
|--------------------------------------------------------------------------
*/

async function acquireLock(
  connection,
  lockName
) {
  const [rows] =
    await connection.query(
      "SELECT GET_LOCK(?, ?) AS acquired",
      [
        lockName,
        LOCK_TIMEOUT_SECONDS,
      ]
    );

  return (
    Number(
      rows[0]?.acquired
    ) === 1
  );
}

async function releaseLock(
  connection,
  lockName
) {
  try {
    await connection.query(
      "SELECT RELEASE_LOCK(?)",
      [lockName]
    );
  } catch (_) {
    // Safe to ignore during shutdown.
  }
}

/*
|--------------------------------------------------------------------------
| CHECK DAILY STATUS
|--------------------------------------------------------------------------
|
| This is the key part.
|
| It uses MySQL persistent state.
|
| Restarting Node does NOT reset this.
|
|--------------------------------------------------------------------------
*/

async function hasSucceededToday(
  connection,
  syncName
) {
  const [rows] =
    await connection.query(
      `
      SELECT id
      FROM mf_sync_status
      WHERE sync_name = ?
        AND status = 'SUCCESS'
        AND last_success_date = CURDATE()
      LIMIT 1
      `,
      [syncName]
    );

  return rows.length > 0;
}

/*
|--------------------------------------------------------------------------
| NAV SYNC
|--------------------------------------------------------------------------
|
| One NAV sync per day from startup.
|
| If today's NAV sync already succeeded:
|     NO API CALL
|
|--------------------------------------------------------------------------
*/

async function ensureDailyNAVSync(
  reason = "startup"
) {
  let connection = null;
  let locked = false;

  try {
    connection =
      await pool.getConnection();

    /*
    ----------------------------------------------------------------------
    Startup lock
    ----------------------------------------------------------------------
    */

    locked =
      await acquireLock(
        connection,
        STARTUP_LOCK_NAME
      );

    if (!locked) {
      console.log(
        `[MF NAV] ${reason}: another startup NAV sync is running.`
      );

      return {
        success: true,
        skipped: true,
        reason: "startup-lock",
      };
    }

    /*
    ----------------------------------------------------------------------
    Do NOT call provider again if already synced today.
    ----------------------------------------------------------------------
    */

    const alreadyDone =
      await hasSucceededToday(
        connection,
        NAV_SYNC_NAME
      );

    if (alreadyDone) {
      console.log(
        `[MF NAV] ${reason}: today's NAV sync already completed.`
      );

      console.log(
        "[MF NAV] No AMFI API call required."
      );

      return {
        success: true,
        skipped: true,
        reason: "already-synced-today",
      };
    }

    /*
    ----------------------------------------------------------------------
    Start NAV sync
    ----------------------------------------------------------------------
    */

    await markRunning(
      NAV_SYNC_NAME,
      connection
    );

    console.log(
      `[MF NAV] ${reason}: starting daily NAV synchronization`
    );

    const result =
      await syncLatestNAV();

    if (
      !result ||
      result.success === false
    ) {
      throw new Error(
        result?.error ||
        "NAV synchronization failed"
      );
    }

    /*
    ----------------------------------------------------------------------
    Never mark success when zero records arrived.
    ----------------------------------------------------------------------
    */

    if (
      Number(
        result.fetched || 0
      ) === 0
    ) {
      throw new Error(
        "NAV synchronization returned zero records"
      );
    }

    await markSuccess(
      NAV_SYNC_NAME,
      {
        processed:
          Number(
            result.fetched || 0
          ),

        updated:
          Number(
            result.updated || 0
          ),

        failed:
          Number(
            result.failed || 0
          ) +
          Number(
            result.invalid || 0
          ),
      },
      connection
    );

    console.log(
      `[MF NAV] ${reason}: completed successfully`
    );

    console.log(
      `[MF NAV] fetched=${result.fetched}`
    );

    console.log(
      `[MF NAV] updated=${result.updated}`
    );

    console.log(
      `[MF NAV] unchanged=${result.unchanged}`
    );

    return {
      ...result,
      success: true,
      skipped: false,
    };

  } catch (error) {

    console.error(
      `[MF NAV] ${reason} failed:`,
      error.message
    );

    try {
      if (connection) {
        await markFailed(
          NAV_SYNC_NAME,
          error.message,
          {},
          connection
        );
      }
    } catch (statusError) {
      console.error(
        "[MF NAV] Could not save failure status:",
        statusError.message
      );
    }

    return {
      success: false,
      skipped: false,
      error: error.message,
    };

  } finally {

    if (
      connection &&
      locked
    ) {
      await releaseLock(
        connection,
        STARTUP_LOCK_NAME
      );
    }

    if (connection) {
      connection.release();
    }
  }
}

/*
|--------------------------------------------------------------------------
| FULL DAILY SYNC
|--------------------------------------------------------------------------
|
| NAV -> returns -> risk -> ratings
|
| This is the expensive part.
|
| It runs in background on startup.
|
|--------------------------------------------------------------------------
*/

async function runFullDailySync(
  reason = "scheduled",
  options = {}
) {
  const skipNAV =
    options.skipNAV === true;

  let connection = null;
  let locked = false;

  try {
    connection =
      await pool.getConnection();

    /*
    ----------------------------------------------------------------------
    Only ONE full pipeline at a time.
    ----------------------------------------------------------------------
    */

    locked =
      await acquireLock(
        connection,
        FULL_SYNC_LOCK_NAME
      );

    if (!locked) {
      console.log(
        `[MF SYNC] ${reason}: another full synchronization is running.`
      );

      return {
        success: true,
        skipped: true,
        reason: "full-sync-lock",
      };
    }

    /*
    ----------------------------------------------------------------------
    If this is a startup background sync, NAV has already been
    synchronized by ensureDailyNAVSync().
    ----------------------------------------------------------------------
    */

    if (!skipNAV) {

      console.log(
        `[MF SYNC] ${reason}: refreshing NAV first`
      );

      /*
      IMPORTANT:
      Scheduled production run deliberately refreshes NAV.
      This allows today's newly published NAV to be picked up.
      */

      const navResult =
        await syncLatestNAV();

      if (
        !navResult ||
        navResult.success === false
      ) {
        throw new Error(
          navResult?.error ||
          "Scheduled NAV synchronization failed"
        );
      }

      await markSuccess(
        NAV_SYNC_NAME,
        {
          processed:
            Number(
              navResult.fetched || 0
            ),

          updated:
            Number(
              navResult.updated || 0
            ),

          failed:
            Number(
              navResult.failed || 0
            ) +
            Number(
              navResult.invalid || 0
            ),
        },
        connection
      );
    }

    /*
    ----------------------------------------------------------------------
    Check whether the complete daily pipeline has already finished.
    ----------------------------------------------------------------------
    */

    const alreadyComplete =
      await hasSucceededToday(
        connection,
        FULL_SYNC_NAME
      );

    if (alreadyComplete) {
      console.log(
        `[MF SYNC] ${reason}: full daily sync already completed today.`
      );

      return {
        success: true,
        skipped: true,
        reason: "already-complete-today",
      };
    }

    /*
    ----------------------------------------------------------------------
    Mark RUNNING
    ----------------------------------------------------------------------
    */

    await markRunning(
      FULL_SYNC_NAME,
      connection
    );

    console.log(
      `[MF SYNC] ${reason}: full daily synchronization started`
    );

    /*
    ======================================================================
    RETURNS + RISK
    ======================================================================
    */

    console.log(
      `[MF SYNC] ${reason}: calculating returns and risk`
    );

    const returnsResult =
      await syncAllReturns();

    console.log(
      `[MF SYNC] ${reason}: returns calculation completed`
    );

    /*
    ======================================================================
    RATINGS
    ======================================================================
    */

    console.log(
      `[MF SYNC] ${reason}: calculating ratings`
    );

    const ratingResult =
      await calculateAllRatings(
        connection
      );

    console.log(
      `[MF SYNC] ${reason}: ratings calculation completed`
    );

    /*
    ----------------------------------------------------------------------
    SUCCESS
    ----------------------------------------------------------------------
    */

    const processed =
      Number(
        returnsResult?.processed || 0
      );

    const updated =
      Number(
        returnsResult?.updated || 0
      ) +
      Number(
        ratingResult?.updated || 0
      );

    const failed =
      Number(
        returnsResult?.failed || 0
      ) +
      Number(
        ratingResult?.failed || 0
      );

    await markSuccess(
      FULL_SYNC_NAME,
      {
        processed,
        updated,
        failed,
      },
      connection
    );

    console.log(
      "================================================"
    );

    console.log(
      `[MF SYNC] ${reason}: FULL DAILY SYNC COMPLETED`
    );

    console.log(
      `[MF SYNC] processed=${processed}`
    );

    console.log(
      `[MF SYNC] updated=${updated}`
    );

    console.log(
      `[MF SYNC] failed=${failed}`
    );

    console.log(
      "================================================"
    );

    return {
      success: true,
      skipped: false,
      returns:
        returnsResult,
      ratings:
        ratingResult,
    };

  } catch (error) {

    console.error(
      `[MF SYNC] ${reason} failed:`,
      error.message
    );

    try {
      if (connection) {
        await markFailed(
          FULL_SYNC_NAME,
          error.message,
          {},
          connection
        );
      }
    } catch (statusError) {
      console.error(
        "[MF SYNC] Could not record full-sync failure:",
        statusError.message
      );
    }

    return {
      success: false,
      skipped: false,
      error: error.message,
    };

  } finally {

    if (
      connection &&
      locked
    ) {
      await releaseLock(
        connection,
        FULL_SYNC_LOCK_NAME
      );
    }

    if (connection) {
      connection.release();
    }
  }
}

/*
|--------------------------------------------------------------------------
| STARTUP
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| The HTTP server should become available immediately.
|
| NAV check happens once.
|
| Full returns/risk calculation runs in background.
|
|--------------------------------------------------------------------------
*/

function runStartupSync() {

  setImmediate(
    async () => {

      console.log(
        "[MF SYNC] Startup synchronization check"
      );

      /*
      --------------------------------------------------------------------
      STEP 1
      --------------------------------------------------------------------
      */

      let navResult = {
        success: true,
        skipped: true,
        reason: "disabled",
      };

      if (
        STARTUP_NAV_SYNC
      ) {

        navResult =
          await ensureDailyNAVSync(
            "startup"
          );

      } else {

        console.log(
          "[MF NAV] Startup NAV sync disabled."
        );
      }

      /*
      --------------------------------------------------------------------
      STEP 2
      --------------------------------------------------------------------
      |
      | Do not block server startup.
      |
      --------------------------------------------------------------------
      */

      if (
        STARTUP_FULL_SYNC &&
        navResult.success
      ) {

        console.log(
          "[MF SYNC] Checking whether today's full sync is required..."
        );

        /*
        Run asynchronously.
        Do NOT await it.
        */

        runFullDailySync(
          "startup-background",
          {
            skipNAV: true,
          }
        ).catch(
          (error) => {
            console.error(
              "[MF SYNC] Background startup sync error:",
              error.message
            );
          }
        );

      } else {

        console.log(
          "[MF SYNC] Full startup sync not started."
        );
      }
    }
  );
}

/*
|--------------------------------------------------------------------------
| DAILY PRODUCTION SCHEDULER
|--------------------------------------------------------------------------
|
| Default:
|
| 23:15 IST
| Monday-Friday
|
|--------------------------------------------------------------------------
*/

function startMFScheduler() {

  if (
    !cron.validate(
      CRON_EXPRESSION
    )
  ) {
    throw new Error(
      `Invalid MF_SYNC_CRON: ${CRON_EXPRESSION}`
    );
  }

  schedulerTask =
    cron.schedule(
      CRON_EXPRESSION,

      () => {

        console.log(
          "[MF SYNC] Scheduled production sync triggered"
        );

        /*
        Scheduled run is intentionally NOT skipped
        based on today's NAV status.

        It refreshes the official AMFI report once
        at the daily production time.
        */

        runFullDailySync(
          "scheduled",
          {
            skipNAV: false,
          }
        ).catch(
          (error) => {
            console.error(
              "[MF SYNC] Scheduled sync error:",
              error.message
            );
          }
        );

      },

      {
        timezone:
          CRON_TIMEZONE,
      }
    );

  console.log(
    `[MF SYNC] Scheduler active: ${CRON_EXPRESSION} (${CRON_TIMEZONE})`
  );

  return schedulerTask;
}

/*
|--------------------------------------------------------------------------
| STOP
|--------------------------------------------------------------------------
*/

function stopMFScheduler() {

  if (
    schedulerTask
  ) {

    schedulerTask.stop();

    schedulerTask =
      null;

    console.log(
      "[MF SYNC] Scheduler stopped"
    );
  }
}

/*
|--------------------------------------------------------------------------
| EXPORTS
|--------------------------------------------------------------------------
*/

module.exports = {
  runStartupSync,
  startMFScheduler,
  stopMFScheduler,
  ensureDailyNAVSync,
  runFullDailySync,
};