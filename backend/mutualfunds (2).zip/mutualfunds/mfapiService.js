// const axios = require('axios');

// const MFAPI_BASE_URL = process.env.MFAPI_BASE_URL || 'https://api.mfapi.in';
// const NAV_DECIMALS = 2;

// function roundNav(value) {
//   const number = Number(value);
//   if (!Number.isFinite(number)) return null;
//   return Number(number.toFixed(NAV_DECIMALS));
// }
// const http = axios.create({
//   baseURL: MFAPI_BASE_URL,
//   timeout: Number(process.env.MFAPI_TIMEOUT_MS || 60000),
//   headers: { Accept: 'application/json', 'User-Agent': 'Zerodha-MF-Module/2.0' },
// });

// const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// function parseNavDate(value) {
//   if (!value) return null;
//   const s = String(value).trim();
//   if (/^\d{2}-\d{2}-\d{4}$/.test(s)) {
//     const [dd, mm, yyyy] = s.split('-');
//     return `${yyyy}-${mm}-${dd}`;
//   }
//   if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
//   const d = new Date(s);
//   return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
// }

// function formatApiDate(date) {
//   const iso = parseNavDate(date);
//   if (!iso) return null;
//   const [yyyy, mm, dd] = iso.split('-');
//   return `${dd}-${mm}-${yyyy}`;
// }

// function subtractDays(dateString, days) {
//   const d = new Date(`${dateString}T00:00:00Z`);
//   d.setUTCDate(d.getUTCDate() - days);
//   return d.toISOString().slice(0, 10);
// }

// function subtractYears(dateString, years) {
//   const d = new Date(`${dateString}T00:00:00Z`);
//   d.setUTCFullYear(d.getUTCFullYear() - years);
//   return d.toISOString().slice(0, 10);
// }

// function addDays(dateString, days) {
//   const d = new Date(`${dateString}T00:00:00Z`);
//   d.setUTCDate(d.getUTCDate() + days);
//   return d.toISOString().slice(0, 10);
// }

// async function getLatestFunds() {
//   // Retry a handful of times with backoff before giving up - a single
//   // transient network blip should not fail the whole daily sync and
//   // must not be treated the same as a hard MFapi outage.
//   let lastError;
//   for (let attempt = 1; attempt <= 4; attempt++) {
//     try {
//       const response = await http.get('/mf/latest');
//       const p = response.data;
//       if (Array.isArray(p)) return p;
//       if (Array.isArray(p?.data)) return p.data;
//       if (Array.isArray(p?.data?.funds)) return p.data.funds;
//       if (Array.isArray(p?.funds)) return p.funds;
//       throw new Error('Unexpected MFapi /mf/latest response format');
//     } catch (err) {
//       lastError = err;
//       if (attempt < 4) await sleep(1000 * attempt);
//     }
//   }
//   throw lastError;
// }

// async function getHistoricalNAV(
//   schemeCode,
//   startDate,
//   endDate
// ) {
//   const url =
//     `${MFAPI_BASE_URL}/mf/${schemeCode}` +
//     `?startDate=${encodeURIComponent(startDate)}` +
//     `&endDate=${encodeURIComponent(endDate)}`;

//   const response = await axios.get(url, {
//     timeout: Number(process.env.MFAPI_TIMEOUT_MS || 60000)
//   });

//   if (!response.data) {
//     return [];
//   }

//   if (Array.isArray(response.data.data)) {
//     return response.data.data.map(row => ({
//       date: row.date,
//       nav: roundNav(row.nav)
//     }));
//   }

//   if (Array.isArray(response.data)) {
//     return response.data.map(row => ({
//       date: row.date,
//       nav: roundNav(row.nav)
//     }));
//   }

//   return [];
// }

// async function getSchemeHistory(schemeCode, startDate, endDate) {
//   const params = {};
//   const start = formatApiDate(startDate);
//   const end = formatApiDate(endDate);
//   if (start) params.startDate = start;
//   if (end) params.endDate = end;

//   let lastError;
//   for (let attempt = 1; attempt <= 4; attempt++) {
//     try {
//       const response = await http.get(`/mf/${schemeCode}`, { params });
//       if (!Array.isArray(response.data?.data)) {
//         throw new Error(`Invalid historical NAV response for scheme ${schemeCode}`);
//       }

//       const byDate = new Map();
//       for (const row of response.data.data) {
//         const date = parseNavDate(row.date);
//         const nav = roundNav(row.nav);
//         if (date && Number.isFinite(nav) && nav > 0) byDate.set(date, nav);
//       }

//       return [...byDate.entries()]
//         .map(([date, nav]) => ({ date, nav }))
//         .sort((a, b) => a.date.localeCompare(b.date));
//     } catch (err) {
//       lastError = err;
//       if (attempt < 4) await sleep(1000 * attempt);
//     }
//   }
//   throw lastError;
// }

// function findNavOnOrBefore(history, targetDate) {
//   let found = null;
//   for (const row of history) {
//     if (row.date <= targetDate) found = row;
//     else break;
//   }
//   return found;
// }

// function calculatePointToPoint(currentNav, oldNav) {
//   if (!Number.isFinite(currentNav) || !Number.isFinite(oldNav) || currentNav <= 0 || oldNav <= 0) return null;
//   return Number((((currentNav / oldNav) - 1) * 100).toFixed(4));
// }

// function calculateCAGR(currentNav, oldNav, years) {
//   if (!Number.isFinite(currentNav) || !Number.isFinite(oldNav) || currentNav <= 0 || oldNav <= 0 || years <= 0) return null;
//   return Number(((Math.pow(currentNav / oldNav, 1 / years) - 1) * 100).toFixed(4));
// }

// function calculateReturns(history, currentNav, currentDate) {
//   if (!history?.length || !Number.isFinite(currentNav) || currentNav <= 0 || !currentDate) {
//     return { return1Y: null, return3Y: null, return5Y: null, nav1YDate: null, nav3YDate: null, nav5YDate: null };
//   }

//   const target1Y = subtractYears(currentDate, 1);
//   const target3Y = subtractYears(currentDate, 3);
//   const target5Y = subtractYears(currentDate, 5);

//   const nav1Y = findNavOnOrBefore(history, target1Y);
//   const nav3Y = findNavOnOrBefore(history, target3Y);
//   const nav5Y = findNavOnOrBefore(history, target5Y);

//   return {
//     // 1Y is point-to-point. For one year this is mathematically the same as CAGR.
//     return1Y: nav1Y ? calculatePointToPoint(currentNav, nav1Y.nav) : null,
//     // 3Y and 5Y are annualized CAGR, which is the standard presentation for multi-year MF returns.
//     return3Y: nav3Y ? calculateCAGR(currentNav, nav3Y.nav, 3) : null,
//     return5Y: nav5Y ? calculateCAGR(currentNav, nav5Y.nav, 5) : null,
//     nav1YDate: nav1Y?.date || null,
//     nav3YDate: nav3Y?.date || null,
//     nav5YDate: nav5Y?.date || null,
//     target1YDate: target1Y,
//     target3YDate: target3Y,
//     target5YDate: target5Y,
//   };
// }

// module.exports = {
//   NAV_DECIMALS,
//   roundNav,
//   getLatestFunds,
//   getSchemeHistory,
//   calculateReturns,
//   calculatePointToPoint,
//   calculateCAGR,
//   parseNavDate,
//   formatApiDate,
//   subtractYears,
//   subtractDays,
//   addDays,
//   findNavOnOrBefore,
//   getHistoricalNAV
// };































const axios = require("axios");

const MFAPI_BASE_URL =
  process.env.MFAPI_BASE_URL ||
  "https://api.mfapi.in";

const AMFI_NAV_URL =
  "https://www.amfiindia.com/spages/NAVAll.txt";

const NAV_DECIMALS = 2;

const MFAPI_TIMEOUT =
  Number(
    process.env.MFAPI_TIMEOUT_MS || 60000
  );

const http = axios.create({
  baseURL: MFAPI_BASE_URL,

  timeout: MFAPI_TIMEOUT,

  headers: {
    Accept: "application/json",
    "User-Agent":
      "Zerodha-MF-Module/2.0",
  },
});

const amfiHttp = axios.create({
  timeout: MFAPI_TIMEOUT,

  headers: {
    Accept: "text/plain",
    "User-Agent":
      "Zerodha-MF-Module/2.0",
  },
});

const sleep = (ms) =>
  new Promise((resolve) =>
    setTimeout(resolve, ms)
  );

/*
|--------------------------------------------------------------------------
| NAV rounding
|--------------------------------------------------------------------------
*/

function roundNav(value) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return null;
  }

  return Number(
    number.toFixed(NAV_DECIMALS)
  );
}

/*
|--------------------------------------------------------------------------
| NAV date parser
|--------------------------------------------------------------------------
|
| Supports:
|
| 07-Aug-2026
| 07-08-2026
| 07/08/2026
| 2026-08-07
|
|--------------------------------------------------------------------------
*/
function parseNavDate(value) {
  if (value === null || value === undefined) {
    return null;
  }

  /*
  |--------------------------------------------------------------------------
  | MySQL DATE/DATETIME returned as JavaScript Date
  |--------------------------------------------------------------------------
  */

  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) {
      return null;
    }

    return value
      .toISOString()
      .slice(0, 10);
  }

  const s = String(value).trim();

  if (!s) {
    return null;
  }

  /*
  |--------------------------------------------------------------------------
  | AMFI format
  | 23-Sep-2026
  |--------------------------------------------------------------------------
  */

  const monthMap = {
    jan: "01",
    feb: "02",
    mar: "03",
    apr: "04",
    may: "05",
    jun: "06",
    jul: "07",
    aug: "08",
    sep: "09",
    oct: "10",
    nov: "11",
    dec: "12",
  };

  let match = s.match(
    /^(\d{2})-([A-Za-z]{3})-(\d{4})$/
  );

  if (match) {
    const dd = match[1];

    const month =
      monthMap[
        match[2].toLowerCase()
      ];

    const yyyy = match[3];

    if (!month) {
      return null;
    }

    return `${yyyy}-${month}-${dd}`;
  }

  /*
  |--------------------------------------------------------------------------
  | DD-MM-YYYY
  |--------------------------------------------------------------------------
  */

  match = s.match(
    /^(\d{2})-(\d{2})-(\d{4})$/
  );

  if (match) {
    return `${match[3]}-${match[2]}-${match[1]}`;
  }

  /*
  |--------------------------------------------------------------------------
  | DD/MM/YYYY
  |--------------------------------------------------------------------------
  */

  match = s.match(
    /^(\d{2})\/(\d{2})\/(\d{4})$/
  );

  if (match) {
    return `${match[3]}-${match[2]}-${match[1]}`;
  }

  /*
  |--------------------------------------------------------------------------
  | YYYY-MM-DD
  |--------------------------------------------------------------------------
  */

  if (
    /^\d{4}-\d{2}-\d{2}$/.test(s)
  ) {
    return s;
  }

  /*
  |--------------------------------------------------------------------------
  | JavaScript date string fallback
  |
  | Example:
  | Wed Sep 23 2026 00:00:00 GMT+0530
  |--------------------------------------------------------------------------
  */

  const parsed =
    new Date(s);

  if (
    !Number.isNaN(
      parsed.getTime()
    )
  ) {
    return parsed
      .toISOString()
      .slice(0, 10);
  }

  return null;
}

/*
|--------------------------------------------------------------------------
| Format date for MFAPI historical endpoint
|--------------------------------------------------------------------------
*/

function formatApiDate(date) {
  const iso =
    parseNavDate(date);

  if (!iso) {
    return null;
  }

  const [
    yyyy,
    mm,
    dd
  ] = iso.split("-");

  return `${dd}-${mm}-${yyyy}`;
}

/*
|--------------------------------------------------------------------------
| Date helpers
|--------------------------------------------------------------------------
*/

function subtractDays(
  dateString,
  days
) {
  const d =
    new Date(
      `${dateString}T00:00:00Z`
    );

  d.setUTCDate(
    d.getUTCDate() -
      days
  );

  return d
    .toISOString()
    .slice(0, 10);
}

function subtractYears(
  dateString,
  years
) {
  const d =
    new Date(
      `${dateString}T00:00:00Z`
    );

  d.setUTCFullYear(
    d.getUTCFullYear() -
      years
  );

  return d
    .toISOString()
    .slice(0, 10);
}

function addDays(
  dateString,
  days
) {
  const d =
    new Date(
      `${dateString}T00:00:00Z`
    );

  d.setUTCDate(
    d.getUTCDate() +
      days
  );

  return d
    .toISOString()
    .slice(0, 10);
}

/*
|--------------------------------------------------------------------------
| Parse AMFI Complete NAV Report
|--------------------------------------------------------------------------
|
| AMFI format:
|
| Scheme Code;
| ISIN Div Payout / ISIN Growth;
| ISIN Div Reinvestment;
| Scheme Name;
| Net Asset Value;
| Date
|
|--------------------------------------------------------------------------
*/
function parseAMFINAVReport(text) {
  const raw = String(text || "")
    .replace(/^\uFEFF/, "")
    .replace(/\r/g, "");

  const lines = raw.split("\n");

  const funds = [];

  for (const line of lines) {
    const trimmed = line.trim();

    if (!trimmed) continue;

    /*
     * AMFI row:
     * SchemeCode;ISIN1;ISIN2;SchemeName;NAV;Date
     */

    const match = trimmed.match(
      /^(\d+);([^;]*);([^;]*);(.+);([0-9]+(?:\.[0-9]+)?);(\d{2}-[A-Za-z]{3}-\d{4})$/
    );

    if (!match) {
      continue;
    }

    const schemeCode = Number(match[1]);

    const isinGrowth =
      String(match[2] || "").trim();

    const isinDivReinvestment =
      String(match[3] || "").trim();

    const schemeName =
      String(match[4] || "").trim();

    const nav =
      Number(match[5]);

    const navDate =
      parseNavDate(match[6]);

    if (
      !Number.isFinite(schemeCode) ||
      schemeCode <= 0 ||
      !Number.isFinite(nav) ||
      nav <= 0 ||
      !navDate
    ) {
      continue;
    }

    funds.push({
      schemeCode,

      nav: roundNav(nav),

      date: navDate,

      navDate,

      schemeName:
        schemeName || null,

      fundHouse: null,

      schemeType: null,

      schemeCategory: null,

      isinGrowth:
        isinGrowth === "-"
          ? null
          : isinGrowth || null,

      isinDivReinvestment:
        isinDivReinvestment === "-"
          ? null
          : isinDivReinvestment || null,
    });
  }

  return funds;
}

/*
|--------------------------------------------------------------------------
| Get latest NAV data
|--------------------------------------------------------------------------
|
| PRIMARY SOURCE:
| AMFI Complete NAV Report
|
| We intentionally DO NOT fall back to /mf/latest.
|
| Reason:
| /mf/latest was the source of the stale-date problem in your project.
| Falling back to it could put an older NAV back into MySQL.
|
|--------------------------------------------------------------------------
*/

async function getLatestFunds() {
  const urls = [
    "https://portal.amfiindia.com/spages/NAVAll.txt",
    "https://www.amfiindia.com/spages/NAVAll.txt",
  ];

  let lastError = null;

  for (const url of urls) {
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        console.log(
          `[MF NAV] Downloading AMFI NAV report: ${url} (attempt ${attempt}/3)...`
        );

        const response = await amfiHttp.get(url, {
          responseType: "arraybuffer",

          transformResponse: [
            (data) => data,
          ],

          headers: {
            Accept:
              "text/plain,text/*,*/*;q=0.8",

            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/153.0.0.0 Safari/537.36",

            Referer:
              "https://www.amfiindia.com/",
          },

          maxRedirects: 5,
        });

        const buffer =
          Buffer.from(response.data);

        /*
         * Decode both common encodings.
         * AMFI's text report is plain text, so UTF-8
         * should normally be enough, but this makes
         * the parser more tolerant.
         */

        let text =
          buffer.toString("utf8");

        if (
          text.includes("\u0000") ||
          text.length < 1000
        ) {
          text =
            buffer.toString("latin1");
        }

        console.log(
          `[MF NAV] AMFI HTTP status: ${response.status}`
        );

        console.log(
          `[MF NAV] AMFI response length: ${text.length}`
        );

        /*
         * Detect HTML / access-denied responses.
         */

        const preview =
          text
            .slice(0, 250)
            .replace(/\s+/g, " ")
            .trim();

        console.log(
          `[MF NAV] AMFI response preview: ${preview}`
        );

        if (
          /<html|<!doctype|access denied|cloudflare/i.test(
            text
          )
        ) {
          throw new Error(
            "AMFI returned HTML/access-denied content instead of NAV text"
          );
        }

        const funds =
          parseAMFINAVReport(text);

        if (
          !Array.isArray(funds) ||
          funds.length === 0
        ) {
          throw new Error(
            "AMFI report downloaded but parser found zero valid NAV rows"
          );
        }

        const dates =
          funds
            .map(
              (fund) =>
                fund.navDate
            )
            .filter(Boolean)
            .sort();

        const latestDate =
          dates.length
            ? dates[dates.length - 1]
            : null;

        console.log(
          `[MF NAV] AMFI records loaded: ${funds.length}`
        );

        console.log(
          `[MF NAV] Latest date present in AMFI report: ${latestDate}`
        );

        return funds;

      } catch (error) {
        lastError = error;

        console.error(
          `[MF NAV] AMFI attempt ${attempt} failed: ${error.message}`
        );

        if (attempt < 3) {
          await sleep(1500 * attempt);
        }
      }
    }
  }

  throw lastError;
}

/*
|--------------------------------------------------------------------------
| Historical NAV
|--------------------------------------------------------------------------
*/

async function getHistoricalNAV(
  schemeCode,
  startDate,
  endDate
) {
  const url =
    `${MFAPI_BASE_URL}/mf/${schemeCode}` +
    `?startDate=${encodeURIComponent(
      startDate
    )}` +
    `&endDate=${encodeURIComponent(
      endDate
    )}`;

  const response =
    await axios.get(
      url,
      {
        timeout:
          MFAPI_TIMEOUT,
      }
    );

  if (
    !response.data
  ) {
    return [];
  }

  if (
    Array.isArray(
      response.data.data
    )
  ) {
    return response.data.data.map(
      (row) => ({
        date:
          parseNavDate(
            row.date
          ),

        nav:
          roundNav(
            row.nav
          ),
      })
    );
  }

  if (
    Array.isArray(
      response.data
    )
  ) {
    return response.data.map(
      (row) => ({
        date:
          parseNavDate(
            row.date
          ),

        nav:
          roundNav(
            row.nav
          ),
      })
    );
  }

  return [];
}

/*
|--------------------------------------------------------------------------
| Scheme history
|--------------------------------------------------------------------------
*/

async function getSchemeHistory(
  schemeCode,
  startDate,
  endDate
) {
  const params = {};

  const start =
    formatApiDate(
      startDate
    );

  const end =
    formatApiDate(
      endDate
    );

  if (start) {
    params.startDate =
      start;
  }

  if (end) {
    params.endDate =
      end;
  }

  let lastError =
    null;

  for (
    let attempt = 1;
    attempt <= 4;
    attempt++
  ) {
    try {
      const response =
        await http.get(
          `/mf/${schemeCode}`,
          {
            params,
          }
        );

      if (
        !Array.isArray(
          response.data?.data
        )
      ) {
        throw new Error(
          `Invalid historical NAV response for scheme ${schemeCode}`
        );
      }

      const byDate =
        new Map();

      for (
        const row of
          response.data.data
      ) {
        const date =
          parseNavDate(
            row.date
          );

        const nav =
          roundNav(
            row.nav
          );

        if (
          date &&
          Number.isFinite(nav) &&
          nav > 0
        ) {
          byDate.set(
            date,
            nav
          );
        }
      }

      return [
        ...byDate.entries(),
      ]
        .map(
          ([date, nav]) => ({
            date,
            nav,
          })
        )
        .sort(
          (a, b) =>
            a.date.localeCompare(
              b.date
            )
        );

    } catch (error) {
      lastError =
        error;

      if (
        attempt < 4
      ) {
        await sleep(
          1000 * attempt
        );
      }
    }
  }

  throw lastError;
}

/*
|--------------------------------------------------------------------------
| Find NAV on or before date
|--------------------------------------------------------------------------
*/

function findNavOnOrBefore(
  history,
  targetDate
) {
  let found =
    null;

  for (
    const row of
      history
  ) {
    if (
      row.date <=
      targetDate
    ) {
      found = row;
    } else {
      break;
    }
  }

  return found;
}

/*
|--------------------------------------------------------------------------
| Point-to-point return
|--------------------------------------------------------------------------
*/

function calculatePointToPoint(
  currentNav,
  oldNav
) {
  if (
    !Number.isFinite(
      currentNav
    ) ||
    !Number.isFinite(
      oldNav
    ) ||
    currentNav <= 0 ||
    oldNav <= 0
  ) {
    return null;
  }

  return Number(
    (
      (
        (
          currentNav /
          oldNav
        ) -
        1
      ) *
      100
    ).toFixed(4)
  );
}

/*
|--------------------------------------------------------------------------
| CAGR
|--------------------------------------------------------------------------
*/

function calculateCAGR(
  currentNav,
  oldNav,
  years
) {
  if (
    !Number.isFinite(
      currentNav
    ) ||
    !Number.isFinite(
      oldNav
    ) ||
    currentNav <= 0 ||
    oldNav <= 0 ||
    years <= 0
  ) {
    return null;
  }

  return Number(
    (
      (
        Math.pow(
          currentNav /
            oldNav,
          1 / years
        ) -
        1
      ) *
      100
    ).toFixed(4)
  );
}

/*
|--------------------------------------------------------------------------
| Calculate returns
|--------------------------------------------------------------------------
*/

function calculateReturns(
  history,
  currentNav,
  currentDate
) {
  if (
    !history?.length ||
    !Number.isFinite(
      currentNav
    ) ||
    currentNav <= 0 ||
    !currentDate
  ) {
    return {
      return1Y: null,
      return3Y: null,
      return5Y: null,

      nav1YDate: null,
      nav3YDate: null,
      nav5YDate: null,
    };
  }

  const target1Y =
    subtractYears(
      currentDate,
      1
    );

  const target3Y =
    subtractYears(
      currentDate,
      3
    );

  const target5Y =
    subtractYears(
      currentDate,
      5
    );

  const nav1Y =
    findNavOnOrBefore(
      history,
      target1Y
    );

  const nav3Y =
    findNavOnOrBefore(
      history,
      target3Y
    );

  const nav5Y =
    findNavOnOrBefore(
      history,
      target5Y
    );

  return {
    return1Y:
      nav1Y
        ? calculatePointToPoint(
            currentNav,
            nav1Y.nav
          )
        : null,

    return3Y:
      nav3Y
        ? calculateCAGR(
            currentNav,
            nav3Y.nav,
            3
          )
        : null,

    return5Y:
      nav5Y
        ? calculateCAGR(
            currentNav,
            nav5Y.nav,
            5
          )
        : null,

    nav1YDate:
      nav1Y?.date ||
      null,

    nav3YDate:
      nav3Y?.date ||
      null,

    nav5YDate:
      nav5Y?.date ||
      null,

    target1YDate:
      target1Y,

    target3YDate:
      target3Y,

    target5YDate:
      target5Y,
  };
}

/*
|--------------------------------------------------------------------------
| Exports
|--------------------------------------------------------------------------
*/

module.exports = {
  NAV_DECIMALS,
  roundNav,
  getLatestFunds,
  getSchemeHistory,
  calculateReturns,
  calculatePointToPoint,
  calculateCAGR,
  parseNavDate,
  formatApiDate,
  subtractYears,
  subtractDays,
  addDays,
  findNavOnOrBefore,
  getHistoricalNAV,
};